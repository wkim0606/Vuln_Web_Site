# Vulnerable Web : vuln_webhack_test.zip
this is the vulnerable web for training.

board/
    board.php
    board_show.php
    board_write.php 등


